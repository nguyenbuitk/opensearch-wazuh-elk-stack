docker build -t logstash-with-plugin .
docker tag logstash-with-plugin repo.myovcloud.com:5000/devops/logstash-syslog-oss:6.8.23
